// ===================================
// APPOINTMENT BOOKING STATE
// ===================================
let bookingState = {
    selectedDoctor: null,
    selectedDate: null,
    selectedTime: null,
    doctorInfo: null
};

// ===================================
// DOCTOR SELECTION
// ===================================
const doctorCards = document.querySelectorAll('.doctor-card');

doctorCards.forEach(card => {
    card.addEventListener('click', function() {
        if (this.hasAttribute('disabled')) return;
        
        // Remove selection from all cards
        doctorCards.forEach(c => c.classList.remove('selected'));
        
        // Add selection to clicked card
        this.classList.add('selected');
        
        // Update booking state
        const doctorId = this.dataset.doctorId;
        bookingState.selectedDoctor = doctorId;
        
        // Get info from data attributes
        bookingState.doctorInfo = {
            name: this.dataset.doctorName,
            specialization: this.dataset.doctorSpec
        };
        
        // Update summary
        updateBookingSummary();
    });
});

// ===================================
// DATE SELECTION
// ===================================
const appointmentDate = document.getElementById('appointmentDate');

if (appointmentDate) {
    // Set minimum date to today
    appointmentDate.min = getTodayDate();
    
    appointmentDate.addEventListener('change', function() {
        bookingState.selectedDate = this.value;
        updateBookingSummary();
    });
}

// ===================================
// TIME SLOT SELECTION
// ===================================
const timeSlots = document.querySelectorAll('.time-slot');

timeSlots.forEach(slot => {
    slot.addEventListener('click', function() {
        // Remove selection from all slots
        timeSlots.forEach(s => s.classList.remove('selected'));
        
        // Add selection to clicked slot
        this.classList.add('selected');
        
        // Update booking state
        bookingState.selectedTime = this.dataset.time;
        
        // Update summary
        updateBookingSummary();
        
        // Reinitialize icons if needed
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    });
});

// ===================================
// UPDATE BOOKING SUMMARY
// ===================================
function updateBookingSummary() {
    const summary = document.getElementById('bookingSummary');
    
    if (bookingState.selectedDoctor && bookingState.selectedDate && bookingState.selectedTime) {
        summary.style.display = 'block';
        
        // Update summary content
        document.getElementById('summaryDoctor').textContent = bookingState.doctorInfo.name;
        document.getElementById('summarySpec').textContent = bookingState.doctorInfo.specialization;
        document.getElementById('summaryDate').textContent = formatDate(bookingState.selectedDate);
        document.getElementById('summaryTime').textContent = bookingState.selectedTime;
        
        // Animate summary
        summary.style.animation = 'fadeIn 0.5s ease';
    } else {
        summary.style.display = 'none';
    }
}

// ===================================
// CONFIRM BOOKING
// ===================================
function confirmBooking() {
    if (!bookingState.selectedDoctor || !bookingState.selectedDate || !bookingState.selectedTime) {
        showAlert('Please fill all fields', 'warning');
        return;
    }
    
    // Populate hidden form
    document.getElementById('formDoctorId').value = bookingState.selectedDoctor;
    document.getElementById('formDate').value = bookingState.selectedDate;
    document.getElementById('formTime').value = bookingState.selectedTime;
    
    // Submit form
    document.getElementById('bookingForm').submit();
}

// ... existing helper functions ..
function getTodayDate() {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

function formatDate(dateString) {
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
}
