// ===================================
// DASHBOARD FUNCTIONS
// ===================================

// Logout Function
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        Storage.remove('currentUser');
        Storage.remove('isLoggedIn');
        showAlert('Logged out successfully', 'success');
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 1000);
    }
}

// Sidebar Toggle for Mobile
const sidebarToggle = document.getElementById('sidebarToggle');
const sidebar = document.getElementById('sidebar');

if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener('click', function() {
        sidebar.classList.toggle('active');
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
        if (window.innerWidth <= 767) {
            if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                sidebar.classList.remove('active');
            }
        }
    });
}

// Update Active Sidebar Link
function updateActiveSidebarLink() {
    const currentPage = window.location.pathname.split('/').pop();
    const sidebarLinks = document.querySelectorAll('.sidebar-link');
    
    sidebarLinks.forEach(link => {
        const linkHref = link.getAttribute('href');
        if (linkHref === currentPage) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
}

// Call on page load
updateActiveSidebarLink();

// ===================================
// DASHBOARD DATA MANAGEMENT
// ===================================

// Mock User Data
const mockUsers = {
    patient: {
        name: 'John Doe',
        email: 'john.doe@email.com',
        phone: '+91 98765 43210',
        address: '123 Main Street, Chennai, TN 600001',
        dateOfBirth: '1990-05-15',
        bloodGroup: 'O+'
    },
    admin: {
        name: 'Administrator',
        email: 'admin@senthilscare.com',
        role: 'Admin'
    }
};

// Get Current User
function getCurrentUser() {
    return Storage.get('currentUser') || mockUsers.patient;
}

// Update Dashboard Welcome
function updateDashboardWelcome() {
    const user = getCurrentUser();
    const welcomeElements = document.querySelectorAll('[data-user-name]');
    
    welcomeElements.forEach(el => {
        el.textContent = `Welcome back, ${user.name}!`;
    });
}

// Update Current Date Display
function updateCurrentDate() {
    const dateElements = document.querySelectorAll('[data-current-date]');
    const today = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' };
    const formattedDate = today.toLocaleDateString('en-US', options);
    
    dateElements.forEach(el => {
        el.textContent = formattedDate;
    });
}

// Call on page load
if (document.querySelector('.dashboard-container')) {
    updateDashboardWelcome();
    updateCurrentDate();
}

// ===================================
// STATS ANIMATION
// ===================================
function animateValue(element, start, end, duration) {
    let startTimestamp = null;
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        const value = Math.floor(progress * (end - start) + start);
        element.textContent = value;
        if (progress < 1) {
            window.requestAnimationFrame(step);
        }
    };
    window.requestAnimationFrame(step);
}

// Animate stats on page load
function animateStats() {
    const statValues = document.querySelectorAll('.stat-value');
    statValues.forEach(el => {
        const finalValue = parseInt(el.textContent);
        if (!isNaN(finalValue)) {
            el.textContent = '0';
            setTimeout(() => {
                animateValue(el, 0, finalValue, 1000);
            }, 200);
        }
    });
}

// Call on dashboard pages
if (document.querySelector('.stat-card')) {
    setTimeout(animateStats, 300);
}

// ===================================
// REFRESH DATA FUNCTION
// ===================================
function refreshDashboard() {
    showAlert('Refreshing dashboard...', 'info');
    
    // Simulate data refresh
    setTimeout(() => {
        animateStats();
        showAlert('Dashboard refreshed successfully', 'success');
    }, 1000);
}

// ===================================
// MODAL FUNCTIONS
// ===================================
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'flex';
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        
        // Animate modal
        setTimeout(() => {
            modal.style.opacity = '1';
        }, 10);
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.opacity = '0';
        setTimeout(() => {
            modal.style.display = 'none';
            modal.classList.remove('show');
            document.body.style.overflow = 'auto';
        }, 300);
    }
}

// Close modal on outside click
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal')) {
        const modalId = e.target.id;
        closeModal(modalId);
    }
});

// Close modal on ESC key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const openModals = document.querySelectorAll('.modal.show');
        openModals.forEach(modal => {
            closeModal(modal.id);
        });
    }
});

// ===================================
// TABLE SORTING
// ===================================
function sortTable(columnIndex, tableId = 'dataTable') {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    
    // Toggle sort direction
    const isAscending = table.dataset.sortDirection !== 'asc';
    table.dataset.sortDirection = isAscending ? 'asc' : 'desc';
    
    // Sort rows
    rows.sort((a, b) => {
        const aValue = a.cells[columnIndex].textContent.trim();
        const bValue = b.cells[columnIndex].textContent.trim();
        
        // Check if numeric
        if (!isNaN(aValue) && !isNaN(bValue)) {
            return isAscending ? aValue - bValue : bValue - aValue;
        }
        
        // String comparison
        return isAscending 
            ? aValue.localeCompare(bValue)
            : bValue.localeCompare(aValue);
    });
    
    // Re-append sorted rows
    rows.forEach(row => tbody.appendChild(row));
}

// ===================================
// SEARCH/FILTER FUNCTIONS
// ===================================
function filterTable(searchTerm, tableId = 'dataTable') {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    const rows = tbody.querySelectorAll('tr');
    const term = searchTerm.toLowerCase();
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(term) ? '' : 'none';
    });
}

// ===================================
// EXPORT FUNCTIONS
// ===================================
function exportTableToCSV(tableId, filename = 'data.csv') {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    let csv = [];
    const rows = table.querySelectorAll('tr');
    
    rows.forEach(row => {
        const cols = row.querySelectorAll('td, th');
        const rowData = Array.from(cols).map(col => {
            return '"' + col.textContent.trim().replace(/"/g, '""') + '"';
        });
        csv.push(rowData.join(','));
    });
    
    // Create download link
    const csvContent = csv.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
    
    showAlert('Data exported successfully', 'success');
}

// ===================================
// PRINT FUNCTION
// ===================================
function printReport() {
    window.print();
}

// ===================================
// NOTIFICATION COUNT UPDATE
// ===================================
function updateNotificationCount() {
    const badge = document.querySelector('.notification-badge');
    const notifications = Storage.get('notifications') || [];
    const unreadCount = notifications.filter(n => !n.read).length;
    
    if (badge) {
        badge.textContent = unreadCount;
        badge.style.display = unreadCount > 0 ? 'flex' : 'none';
    }
}

// Call on page load
updateNotificationCount();
