# Setup Guide: Smart Patient Appointment System (Python Flask + XAMPP)

Unlike PHP projects which you place inside `htdocs`, this is a **Python Flask application**. You run the Python code separately, but it connects to the XAMPP database.

## Prerequisites

1.  **XAMPP** (for the Database)
2.  **Python** (to run the application)

## Step 1: Database Setup (XAMPP)

1.  Open **XAMPP Control Panel**.
2.  Start **Apache** and **MySQL**.
3.  Open your browser and go to: [http://localhost/phpmyadmin](http://localhost/phpmyadmin)
4.  Click **New** (sidebar) to create a database.
5.  Database Name: `smart_patient_system` (Must match specifically).
6.  Click **Create**.
7.  Select the `smart_patient_system` database on the left.
8.  Click the **Import** tab at the top.
9.  Click **Choose File** and select the `database.sql` file from this project folder.
10. Click **Import** (at the bottom).

## Step 2: Run the Application

There are two ways to run the application:

### Option A: Using the easy script (Recommended)
1.  Double-click `run_app.bat` in the project folder.
2.  It will install dependencies and start the server.

### Option B: Manual Command Line
1.  Open VS Code or Command Prompt in the project folder.
2.  Install dependencies:
    ```bash
    pip install -r requirements.txt
    ```
3.  Run the app:
    ```bash
    python app.py
    ```

## Step 3: Access the App

Once the server is running, open your browser and go to:
[http://127.0.0.1:5000](http://127.0.0.1:5000)

---

**Note**: Keep XAMPP (MySQL) running while using the app.
