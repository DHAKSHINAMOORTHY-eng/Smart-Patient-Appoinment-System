import MySQLdb
from werkzeug.security import generate_password_hash
from app import app, mysql

with app.app_context():
    # Generate a valid hash for 'admin123'
    new_hash = generate_password_hash('admin123')
    print(f"Generated new hash: {new_hash}")
    
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    
    # Update the admin record
    cursor.execute("UPDATE admins SET password_hash = %s WHERE username = 'admin'", (new_hash,))
    mysql.connection.commit()
    
    print("Successfully updated admin password to 'admin123' in the database.")
