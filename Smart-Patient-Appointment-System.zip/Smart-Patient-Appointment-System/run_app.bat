@echo off
echo Starting Smart Patient Appointment System...
echo.
echo ensure you have XAMPP running Apache and MySQL!
echo.
pip install -r requirements.txt
python app.py
pause
