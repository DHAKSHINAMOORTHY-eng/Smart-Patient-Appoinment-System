from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
from datetime import datetime

patient_bp = Blueprint('patient', __name__)

def get_db():
    from app import mysql
    return mysql

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'loggedin' not in session or session.get('role') != 'patient':
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

@patient_bp.route('/dashboard')
@login_required
def dashboard():
    cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
    
    # Get upcoming appointments
    cursor.execute('''
        SELECT a.*, d.name as doctor_name, d.specialization 
        FROM appointments a 
        JOIN doctors d ON a.doctor_id = d.id 
        WHERE a.patient_id = %s AND a.appointment_date >= CURDATE() AND a.status != 'Cancelled'
        ORDER BY a.appointment_date ASC, a.appointment_time ASC 
        LIMIT 1
    ''', (session['id'],))
    upcoming_appointment = cursor.fetchone()
    
    # Get stats
    cursor.execute("SELECT COUNT(*) as total FROM appointments WHERE patient_id = %s", (session['id'],))
    total_appointments = cursor.fetchone()['total']
    
    cursor.execute("SELECT COUNT(*) as pending FROM appointments WHERE patient_id = %s AND status = 'Pending'", (session['id'],))
    pending_appointments = cursor.fetchone()['pending']
    
    cursor.execute("SELECT COUNT(*) as completed FROM appointments WHERE patient_id = %s AND status = 'Completed'", (session['id'],))
    completed_appointments = cursor.fetchone()['completed']

    cursor.execute("SELECT COUNT(*) as cancelled FROM appointments WHERE patient_id = %s AND status = 'Cancelled'", (session['id'],))
    cancelled_appointments = cursor.fetchone()['cancelled']
    
    # Get recent activity (last 5 appointments)
    cursor.execute('''
        SELECT a.*, d.name as doctor_name 
        FROM appointments a 
        JOIN doctors d ON a.doctor_id = d.id 
        WHERE a.patient_id = %s 
        ORDER BY a.created_at DESC 
        LIMIT 5
    ''', (session['id'],))
    recent_activity = cursor.fetchall()

    return render_template('patient-dashboard.html', 
                         upcoming=upcoming_appointment,
                         total=total_appointments,
                         pending=pending_appointments,
                         completed=completed_appointments,
                         cancelled=cancelled_appointments,
                         recent=recent_activity)

@patient_bp.route('/book-appointment', methods=['GET', 'POST'])
@login_required
def book_appointment():
    cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
    
    if request.method == 'POST':
        doctor_id = request.form['doctor_id']
        date = request.form['date']
        time = request.form['time']
        
        # Check availability
        cursor.execute('SELECT * FROM appointments WHERE doctor_id = %s AND appointment_date = %s AND appointment_time = %s AND status != "Cancelled"', (doctor_id, date, time))
        existing = cursor.fetchone()
        
        if existing:
            flash('This slot is already booked. Please choose another.', 'error')
        else:
            cursor.execute('INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time) VALUES (%s, %s, %s, %s)', (session['id'], doctor_id, date, time))
            
            # Add notification
            message = f"Appointment booked for {date} at {time}"
            cursor.execute('INSERT INTO notifications (user_id, message) VALUES (%s, %s)', (session['id'], message))
            
            get_db().connection.commit()
            flash('Appointment booked successfully!', 'success')
            return redirect(url_for('patient.my_appointments'))

    cursor.execute('SELECT * FROM doctors WHERE is_available = 1')
    doctors = cursor.fetchall()
    return render_template('book-appointment.html', doctors=doctors)

@patient_bp.route('/my-appointments')
@login_required
def my_appointments():
    cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('''
        SELECT a.*, d.name as doctor_name, d.specialization 
        FROM appointments a 
        JOIN doctors d ON a.doctor_id = d.id 
        WHERE a.patient_id = %s 
        ORDER BY a.appointment_date DESC, a.appointment_time DESC
    ''', (session['id'],))
    appointments = cursor.fetchall()
    return render_template('my-appointments.html', appointments=appointments)

@patient_bp.route('/appointment/cancel/<int:id>')
@login_required
def cancel_appointment(id):
    cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
    # Verify appointment belongs to patient
    cursor.execute('SELECT * FROM appointments WHERE id = %s AND patient_id = %s', (id, session['id']))
    appointment = cursor.fetchone()
    
    if appointment:
        cursor.execute('UPDATE appointments SET status = "Cancelled" WHERE id = %s', (id,))
        
        # Add notification
        message = f"Appointment on {appointment['appointment_date']} cancelled"
        cursor.execute('INSERT INTO notifications (user_id, message) VALUES (%s, %s)', (session['id'], message))
        
        get_db().connection.commit()
        flash('Appointment cancelled successfully.', 'success')
    else:
        flash('Appointment not found or access denied.', 'error')
        
    return redirect(url_for('patient.my_appointments'))

@patient_bp.route('/notifications')
@login_required
def notifications():
    cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM notifications WHERE user_id = %s ORDER BY created_at DESC', (session['id'],))
    notifications = cursor.fetchall()
    
    # Mark as read (optional logic, maybe on specific action or mark-all-read button)
    
    return render_template('notifications.html', notifications=notifications)

@patient_bp.route('/notifications/read/<int:id>')
@login_required
def mark_notification_read(id):
    cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('UPDATE notifications SET is_read = 1 WHERE id = %s AND user_id = %s', (id, session['id']))
    get_db().connection.commit()
    return redirect(url_for('patient.notifications'))

@patient_bp.route('/appointment/reschedule/<int:id>', methods=['GET', 'POST'])
@login_required
def reschedule_appointment(id):
    cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
    
    # Verify appointment belongs to patient
    cursor.execute('SELECT a.*, d.name as doctor_name, d.specialization FROM appointments a JOIN doctors d ON a.doctor_id = d.id WHERE a.id = %s AND a.patient_id = %s', (id, session['id']))
    appointment = cursor.fetchone()
    
    if not appointment:
        flash('Appointment not found or access denied.', 'error')
        return redirect(url_for('patient.my_appointments'))
        
    if request.method == 'POST':
        new_date = request.form['date']
        new_time = request.form['time']
        
        # Check availability (excluding current appointment)
        cursor.execute('SELECT * FROM appointments WHERE doctor_id = %s AND appointment_date = %s AND appointment_time = %s AND status != "Cancelled" AND id != %s', (appointment['doctor_id'], new_date, new_time, id))
        existing = cursor.fetchone()
        
        if existing:
            flash('This slot is already booked. Please choose another.', 'error')
        else:
            cursor.execute('UPDATE appointments SET appointment_date = %s, appointment_time = %s, status = "Rescheduled" WHERE id = %s', (new_date, new_time, id))
            
            # Add notification
            message = f"Appointment rescheduled to {new_date} at {new_time}"
            cursor.execute('INSERT INTO notifications (user_id, message) VALUES (%s, %s)', (session['id'], message))
            
            get_db().connection.commit()
            flash('Appointment rescheduled successfully!', 'success')
            return redirect(url_for('patient.my_appointments'))

    return render_template('reschedule-appointment.html', appointment=appointment)

@patient_bp.route('/profile')
@login_required
def profile():
    cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM patients WHERE id = %s', (session['id'],))
    patient = cursor.fetchone()
    return render_template('patient-profile.html', patient=patient)

@patient_bp.route('/profile/update', methods=['POST'])
@login_required
def update_profile():
    if request.method == 'POST':
        full_name = request.form['full_name']
        email = request.form['email']
        phone = request.form['phone']
        age = request.form['age']
        address = request.form['address']
        
        cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('''
            UPDATE patients 
            SET full_name = %s, email = %s, phone = %s, age = %s, address = %s 
            WHERE id = %s
        ''', (full_name, email, phone, age, address, session['id']))
        get_db().connection.commit()
        
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('patient.profile'))
