from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
from datetime import datetime

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

def get_db():
    from app import mysql
    return mysql

def admin_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'loggedin' not in session or session.get('role') != 'admin':
            flash('Admin access required.', 'warning')
            return redirect(url_for('auth.admin_login'))
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route('/dashboard')
@admin_required
def dashboard():
    cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
    
    # Stats
    cursor.execute('SELECT COUNT(*) as total FROM patients')
    total_patients = cursor.fetchone()['total']
    
    cursor.execute('SELECT COUNT(*) as total FROM doctors')
    total_doctors = cursor.fetchone()['total']
    
    cursor.execute('SELECT COUNT(*) as total FROM appointments WHERE appointment_date = CURDATE()')
    today_appointments = cursor.fetchone()['total']
    
    cursor.execute('SELECT COUNT(*) as total FROM appointments')
    all_appointments = cursor.fetchone()['total']

    # Quick Stats
    cursor.execute("SELECT COUNT(*) as total FROM appointments WHERE status = 'Completed' AND appointment_date = CURDATE()")
    completed_today = cursor.fetchone()['total']

    cursor.execute("SELECT COUNT(*) as total FROM appointments WHERE status = 'Pending'")
    pending_count = cursor.fetchone()['total']

    # Revenue (Assuming 500 per completed appointment this month)
    cursor.execute("SELECT COUNT(*) as total FROM appointments WHERE status = 'Completed' AND MONTH(appointment_date) = MONTH(CURDATE()) AND YEAR(appointment_date) = YEAR(CURDATE())")
    completed_month = cursor.fetchone()['total']
    revenue_month = completed_month * 500
    
    # Recent Appointments
    cursor.execute('''
        SELECT a.*, p.full_name as patient_name, d.name as doctor_name 
        FROM appointments a 
        JOIN patients p ON a.patient_id = p.id 
        JOIN doctors d ON a.doctor_id = d.id 
        ORDER BY a.created_at DESC 
        LIMIT 5
    ''')
    recent_appointments = cursor.fetchall()
    
    # Weekly Appointments Chart Data (Current Week: Mon-Sun)
    weekly_labels = []
    weekly_data = []
    
    # Get start of current week (Monday)
    from datetime import timedelta
    today = datetime.now().date()
    start_of_week = today - timedelta(days=today.weekday())
    
    for i in range(7):
        day = start_of_week + timedelta(days=i)
        day_str = day.strftime("%Y-%m-%d")
        day_label = day.strftime("%a") # Mon, Tue, etc.
        
        cursor.execute("SELECT COUNT(*) as total FROM appointments WHERE appointment_date = %s", (day_str,))
        count = cursor.fetchone()['total']
        
        weekly_labels.append(day_label)
        weekly_data.append(count)

    now_date = datetime.now().strftime("%d %b, %Y")

    return render_template('admin-dashboard.html', 
                         total_patients=total_patients,
                         total_doctors=total_doctors,
                         today_appointments=today_appointments,
                         all_appointments=all_appointments,
                         completed_today=completed_today,
                         pending_count=pending_count,
                         revenue_month=revenue_month,
                         recent_appointments=recent_appointments,
                         now_date=now_date,
                         weekly_labels=weekly_labels,
                         weekly_data=weekly_data)

@admin_bp.route('/doctors')
@admin_required
def manage_doctors():
    cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM doctors')
    doctors = cursor.fetchall()
    return render_template('manage-doctors.html', doctors=doctors)

@admin_bp.route('/doctors/add', methods=['POST'])
@admin_required
def add_doctor():
    if request.method == 'POST':
        name = request.form['name']
        specialization = request.form['specialization']
        days = request.form['available_days']
        time = request.form['available_time']
        
        cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('INSERT INTO doctors (name, specialization, available_days, available_time) VALUES (%s, %s, %s, %s)', (name, specialization, days, time))
        get_db().connection.commit()
        flash('Doctor added successfully!', 'success')
        return redirect(url_for('admin.manage_doctors'))

@admin_bp.route('/doctors/update/<int:id>', methods=['POST'])
@admin_required
def update_doctor(id):
    if request.method == 'POST':
        name = request.form['name']
        specialization = request.form['specialization']
        days = request.form['available_days']
        time = request.form['available_time']
        
        cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('UPDATE doctors SET name = %s, specialization = %s, available_days = %s, available_time = %s WHERE id = %s', (name, specialization, days, time, id))
        get_db().connection.commit()
        flash('Doctor updated successfully!', 'success')
        return redirect(url_for('admin.manage_doctors'))

@admin_bp.route('/doctors/delete/<int:id>')
@admin_required
def delete_doctor(id):
    cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('DELETE FROM doctors WHERE id = %s', (id,))
    get_db().connection.commit()
    flash('Doctor deleted successfully!', 'success')
    return redirect(url_for('admin.manage_doctors'))

@admin_bp.route('/patients')
@admin_required
def manage_patients():
    cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM patients')
    patients = cursor.fetchall()
    return render_template('manage-patients.html', patients=patients)

@admin_bp.route('/patients/delete/<int:id>')
@admin_required
def delete_patient(id):
    cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('DELETE FROM patients WHERE id = %s', (id,))
    get_db().connection.commit()
    flash('Patient deleted successfully!', 'success')
    return redirect(url_for('admin.manage_patients'))

@admin_bp.route('/appointments')
@admin_required
def view_appointments():
    cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('''
        SELECT a.*, p.full_name as patient_name, d.name as doctor_name 
        FROM appointments a 
        JOIN patients p ON a.patient_id = p.id 
        JOIN doctors d ON a.doctor_id = d.id 
        ORDER BY a.appointment_date DESC
    ''')
    appointments = cursor.fetchall()
    return render_template('view-appointments.html', appointments=appointments)

@admin_bp.route('/appointments/delete/<int:id>')
@admin_required
def delete_appointment(id):
    cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('DELETE FROM appointments WHERE id = %s', (id,))
    get_db().connection.commit()
    flash('Appointment deleted successfully!', 'success')
    return redirect(url_for('admin.view_appointments'))

@admin_bp.route('/appointments/update_status/<int:id>', methods=['POST'])
@admin_required
def update_appointment_status(id):
    if request.method == 'POST':
        new_status = request.form['status']
        cursor = get_db().connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('UPDATE appointments SET status = %s WHERE id = %s', (new_status, id))
        get_db().connection.commit()
        flash('Appointment status updated successfully!', 'success')
        return redirect(url_for('admin.view_appointments'))
