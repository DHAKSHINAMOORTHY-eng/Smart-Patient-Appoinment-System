import MySQLdb
from config import Config

def setup_database():
    print("Setting up database...")
    try:
        # Connect to MySQL server (no database selected yet)
        db = MySQLdb.connect(
            host=Config.MYSQL_HOST,
            user=Config.MYSQL_USER,
            passwd=Config.MYSQL_PASSWORD
        )
        cursor = db.cursor()
        
        # Create Database
        db_name = Config.MYSQL_DB
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
        print(f"[OK] Database '{db_name}' check/creation successful.")
        
        # Select Database
        db.select_db(db_name)
        
        # Read and Execute SQL file
        try:
            with open('database.sql', 'r') as f:
                sql_commands = f.read().split(';')
                for command in sql_commands:
                    if command.strip():
                        cursor.execute(command)
            db.commit()
            print("[OK] Database schema imported successfully.")
        except FileNotFoundError:
            print("[FAIL] 'database.sql' file not found.")
        
        db.close()
        
    except MySQLdb.Error as e:
        print(f"[FAIL] Database setup failed: {e}")
        print("Ensure XAMPP MySQL is running.")

if __name__ == "__main__":
    setup_database()
