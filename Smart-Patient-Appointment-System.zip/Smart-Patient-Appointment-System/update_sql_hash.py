from werkzeug.security import generate_password_hash

# Generate new valid hash
new_hash = generate_password_hash('admin123')
print(f"Generated hash: {new_hash}")

# Read database.sql
with open('database.sql', 'r') as f:
    content = f.read()

# Replace the old hash placeholder or previous hash with the new one
# The previous line was: ('admin', 'scrypt:32768:8:1$QT5kXdf43a855fe63566bcf7249d1f'); 
# or similar. We should find the line starting with ('admin', and replace the hash part.

import re
# Regex to find the admin insert line and replace the hash
# Pattern: ('admin', 'ANY_STRING_HERE');
new_content = re.sub(r"\('admin', '[^']+'\);", f"('admin', '{new_hash}');", content)

with open('database.sql', 'w') as f:
    f.write(new_content)

print("Updated database.sql with new valid hash.")
