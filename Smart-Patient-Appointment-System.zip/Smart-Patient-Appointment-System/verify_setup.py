import os
import sys
from flask import Flask
from flask_mysqldb import MySQL
from config import Config

app = Flask(__name__)
app.config.from_object(Config)
try:
    mysql = MySQL(app)
except Exception as e:
    print(f"Error initializing MySQL: {e}")
    sys.exit(1)

def check_setup():
    print("Checking system setup...")
    
    # 1. Check directories
    required_dirs = ['templates', 'static', 'static/css', 'static/js', 'routes']
    for d in required_dirs:
        if os.path.exists(d):
            print(f"[OK] Directory '{d}' exists.")
        else:
            print(f"[FAIL] Directory '{d}' MISSING!")

    # 2. Check Database Connection
    try:
        with app.app_context():
            conn = mysql.connection
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            print("[OK] Database connection successful.")
            
            # 3. Check Tables
            tables = ['admins', 'patients', 'doctors', 'appointments', 'notifications']
            cursor.execute("SHOW TABLES")
            existing_tables = [table[0] for table in cursor.fetchall()]
            
            for table in tables:
                if table in existing_tables:
                    print(f"[OK] Table '{table}' exists.")
                else:
                    print(f"[FAIL] Table '{table}' MISSING!")
                    
    except Exception as e:
        print(f"[FAIL] Database connection failed: {e}")
        print("Ensure XAMPP MySQL is running and database 'smart_patient_system' exists.")

if __name__ == "__main__":
    check_setup()
