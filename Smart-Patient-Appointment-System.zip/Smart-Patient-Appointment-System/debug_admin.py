import MySQLdb
from werkzeug.security import check_password_hash, generate_password_hash
from app import app, mysql

with app.app_context():
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute("SELECT * FROM admins WHERE username = 'admin'")
    admin = cursor.fetchone()
    
    if admin:
        print(f"Admin found: {admin['username']}")
        print(f"Stored hash: {admin['password_hash']}")
        
        is_valid = check_password_hash(admin['password_hash'], 'admin123')
        print(f"Password 'admin123' valid? {is_valid}")
        
        if not is_valid:
            print("Generating new hash for 'admin123'...")
            new_hash = generate_password_hash('admin123')
            print(f"New hash: {new_hash}")
            print("You can update the database with this new hash if needed.")
    else:
        print("Admin user 'admin' not found in database.")
